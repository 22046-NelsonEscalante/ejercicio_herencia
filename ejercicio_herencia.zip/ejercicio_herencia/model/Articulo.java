package model;

public class Articulo {
    private String arbitro;
    private String autor;


    public String getArbitro() {
        return arbitro;
    }
    public void setArbitro(String arbitro) {
        this.arbitro = arbitro;
    }
    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor;
    }
}
